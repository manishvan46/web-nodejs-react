var answer=require("./custommodules.js");
console.log(answer);
console.log(answer.username);
console.log(answer.userinfo.age);